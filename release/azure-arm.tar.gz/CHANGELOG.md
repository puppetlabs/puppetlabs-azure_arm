# Version 0.6.0
	
 - Tasks generation
 - PDK Validation
 - Puppet6 support
	
# Version 0.5.0
	
 - Providers for deleting deployment
 - An example for deleting deployment
 - Bug fixes
	
# Version 0.4.0
	
 - Providers for creating deployment
 - An example for creating deployment
 - An example for deploying application
 - Bug fixes
	
# Version 0.3.0
	
 - Providers for aks service
 - An example for creating kubernetes service
 - Bug fixes
	
# Version 0.2.0
	
 - Readme fixes
 - Bug fixes

# Version 0.1.0
 - Initial release
