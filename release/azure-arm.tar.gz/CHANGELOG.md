# Version 0.2.1
	
 - Bug fixes
 - Readme fixes

# Version 0.2.0
	
 - Tasks generation
 - PDK Validation
 - Puppet6 support
	
# Version 0.1.5
	
 - Providers for deleting deployment
 - An example for deleting deployment
 - Bug fixes
	
# Version 0.1.4
	
 - Providers for creating deployment
 - An example for creating deployment
 - An example for deploying application
 - Bug fixes
	
# Version 0.1.3
	
 - Providers for aks service
 - An example for creating kubernetes service
 - Bug fixes

# Version 0.1.2

 - Readme fixes

# Version 0.1.1
	
 - Readme fixes
 - Bug fixes

# Version 0.1.0
 - Initial release
